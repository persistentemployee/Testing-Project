let allProducts = [];
let currentProducts = [];
let searchedInput = "";
 
let allViews = ["products-list", "product-details", "cart-details", "checkout"];
 
let activeView = "products-list";
 
let filters = {
    categories: [],
    sort: null
  };
 
  window.addEventListener('DOMContentLoaded', () => {
    loadHomePage();
    setupNavButtons();
  });
 
function setupNavButtons() {
  // document.getElementById('home-btn').addEventListener('click', loadHomePage);
  // document.getElementById('cart-btn').addEventListener('click', loadCartPage);
  // document.getElementById('wishlist-btn').addEventListener('click', loadWishlistPage);
}
 
function setupFiltersAndSorting() {
    document.getElementById('filter-form').addEventListener('change', applyFilters);
    // document.getElementById('sort-price').addEventListener('change', applySorting);
  }
 
// Load Home/Product List Page
function loadHomePage() {
  const mainContent = document.getElementById('product-list');
  mainContent.innerHTML = '<div class="loading">Loading products...</div>';
 
  fetchProducts().then(products => {
    console.log({ products });
    allProducts = [...products];
    renderProducts();
    renderForm();
  });
}
 
function renderProducts(pageNumber) {
  const contentArea = document.getElementById('product-list');
  let filteredProducts = applyCategoryFilters();
  filteredProducts = sortProducts(filteredProducts);
  filteredProducts = getFilteredProductsAfterSearch(filteredProducts, searchedInput);
  
  displayedProducts = [...filteredProducts];
 
  if (pageNumber) {
    let startIdx = (pageNumber - 1) * 6;
    let endIdx = startIdx + 6;
    filteredProducts = filteredProducts.slice(startIdx, endIdx);
  }
 
  let productCardsHTML = filteredProducts.slice(0, 6).map(product => `
    <div class="product-items" onclick="loadProductDetails(${product.id})">
      <img src="${product.image}" alt="${product.title}" loading="lazy">
      <h3>${product.title}</h3>
      <p>$${product.price}</p>
      <i class="fa-regular fa-heart" onclick="addToWishlist(${product.id})"></i>
    </div>
  `).join('');
 
  contentArea.innerHTML = productCardsHTML;
  setTotalCount();
  setupPagination(displayedProducts);
};
 
  function applyCategoryFilters() {
    if (filters.categories.length > 0) {
      return allProducts.filter(product => filters.categories.includes(product.category));
    }
    return allProducts;
  }
 
  // Apply Sorting (Ascending or Descending)
  function getProductsAfterSorting(products) {
    console.log("applySorting")
    const sortValue = filters.sort;
    console.log({ sortValue })
    if (sortValue === 'asc') {
      return products.sort((a, b) => a.price - b.price);
    } else if (sortValue === 'desc') {
      return products.sort((a, b) => b.price - a.price);
    }
 
    return products; // No sorting applied
  }
 
  // Handle Filter Changes
  function applyFilters() {
    console.log("applyFilters")
 
    const selectedCategories = Array.from(document.querySelectorAll('input[name="category"]:checked'))
      .map(checkbox => checkbox.value);
 
    filters.categories = selectedCategories;
 
    // Reload products based on the new filters
      renderProducts();
  }
 
  // Handle Sorting Changes
  function applySorting() {
    console.log("applySorting")
    const selectedSort = document.getElementById('sort-price').value;
    filters.sort = selectedSort;
 
    // Reload products based on the new sorting
    renderProducts();
  }
 
// Load Product Details Page
window.loadProductDetails = function(productId) {
  resetProductsListPageBeforeLoadingProductDetails();
  const product = getProductById(productId);
  console.log({ product })
  const productCardDetails = document.getElementById('product-card-details');
  
  const leftSideImages = document.createElement("div");
  leftSideImages.classList.add("img");
 
  let productThumbnails = new Array(5).fill("").map(ele => `
    <img src="${product.image}" alt="${product.title}">
  `).join('');
  leftSideImages.innerHTML = `${productThumbnails}`;
 
  const rightSideImageDiv = document.createElement("div");
  rightSideImageDiv.classList.add("left");
  const rightSideImage = document.createElement("img");
  rightSideImage.setAttribute("src", product.image);
  rightSideImageDiv.append(rightSideImage);
  productCardDetails.append(leftSideImages);
  productCardDetails.append(rightSideImageDiv);
  
  const rightDiv = document.createElement("div");
  rightDiv.classList.add("right");
  
  const productDetails = `
    <h6>Clothing / ${product.category} / OuterWear</h6>
        <h2>${product.title}</h2>
        <h2>$${product.price}</h2>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-regular fa-star"></i> <span>(175)</span>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. <br>Dolorum nulla iste dolores beatae cum modi. <a href="#">Read More</a></p>
        <hr>
        <h4>Quantity</h4>
        <button id="decrease" class="btn-incrs">-</button>
        <input type="number" id="quantity" value="1" min="1" max="10" class="btn-set">
        <button id="increase" class="btn-incrs">+</button> <br>
        <button id="add-to-cart-btn" class="add-btn">Add To Cart</button>
        <div class="share">
            <i class="fa-regular fa-heart"></i> Save
            <i class="fa-solid fa-share"></i> Share
        </div>
  `;
  const pageBanner = document.getElementById("page-banner");
  pageBanner.style.display = "none";
 
  rightDiv.innerHTML = productDetails;
  productCardDetails.append(rightDiv);
 
  const productDetailsContent = document.getElementById("product-card-content");
  const productTitle = document.createElement("h2")
  productTitle.classList.add("content-1");
  productTitle.innerText = product.title;
  const productDescHeading = document.createElement("h4")
  productDescHeading.classList.add("content-2");
  productDescHeading.innerText = "Description";
  const description = document.createElement("p")
  description.classList.add("content-3");
  description.innerText = product.description;
  productDetailsContent.append(productTitle);
  productDetailsContent.append(productDescHeading);
  productDetailsContent.append(description);
 
  // Add event listeners for quantity buttons
  setupQuantityButtons();
  document.getElementById('add-to-cart-btn').addEventListener('click', () => {
    const quantity = parseInt(document.getElementById('quantity').value);
    addToCart(product, quantity);
    window.location.href = './cart.html';
  });
}
 
function setupQuantityButtons() {
    const increaseBtn = document.getElementById('increase');
    const decreaseBtn = document.getElementById('decrease');
    const quantityInput = document.getElementById('quantity');
 
    // Increase quantity
    increaseBtn.addEventListener('click', () => {
      let currentValue = parseInt(quantityInput.value);
      if (currentValue < 10) {
        quantityInput.value = currentValue + 1;
      }
    });
 
    // Decrease quantity
    decreaseBtn.addEventListener('click', () => {
      let currentValue = parseInt(quantityInput.value);
      if (currentValue > 1) {
        quantityInput.value = currentValue - 1;
      }
    });
  }
 
// Pagination Setup
function setupPagination(products) {
  const paginationDiv = document.getElementById("pagination");
  paginationDiv.innerHTML = "";
 
  let totalPages = Math.ceil(products.length / 6);
 
  for (let i = 1; i <= totalPages; i++) {
    let pageButton = document.createElement('a');
    pageButton.textContent = i;
    pageButton.addEventListener('click', () => renderProducts(i));
    paginationDiv.appendChild(pageButton);
  }
}
 
 
// Function to render the form dynamically
function renderForm() {
  const filterBox = document.createElement("div");
  filterBox.classList.add("filterbox");
  
  // Create h5 element
  const h5 = document.createElement("h5");
  h5.textContent = "Clothing/ Women's/ Outerwear";
  
  // Create h4 element for Filters heading
  const h4Filters = document.createElement("h4");
  h4Filters.textContent = "Filters";
  
  // Create hr (horizontal rule)
  const hr = document.createElement("hr");
  
  // Create div for category list
  const categoryList = document.createElement("div");
  categoryList.classList.add("CategoryList");
  
  // Create h4 element for Categories heading
  const h4Categories = document.createElement("h4");
  h4Categories.textContent = "Categories";
 
  const form = document.createElement("form");
  form.setAttribute('id', "filter-form");
  
  // Array of categories
  const categories = [
    { value: "men's clothing", label: "Men's Clothing" },
    { value: "jewelery", label: "Jewellery" },
    { value: "electronics", label: "Electronics" },
    { value: "women's clothing", label: "Women's Clothing" }
  ];
  
  categories.forEach(category => {
    const label = document.createElement('label');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.name = 'category';
    checkbox.value = category.value;
    label.appendChild(checkbox);
    label.appendChild(document.createTextNode(category.label));
    categoryList.appendChild(label);
  });
 
  form.append(categoryList);
 
 
  // Append all created elements to filterBox
  filterBox.appendChild(h5);
  filterBox.appendChild(h4Filters);
  filterBox.appendChild(hr);
  filterBox.appendChild(form);
  categoryList.insertBefore(h4Categories, categoryList.firstChild);
   
  // Finally, append the filterBox to the container in the DOM
  document.getElementById("filters").append(filterBox);
  setupFiltersAndSorting();
};
 
 
function resetProductsListPageBeforeLoadingProductDetails() {
  const productList = document.getElementById('product-list');
  const filtersDiv = document.getElementById('filters');
  const paginationDiv = document.getElementById('pagination');
  productList.innerHTML = "";
  filtersDiv.innerHTML = "";
  paginationDiv.innerHTML = "";
}

function onChangeSearch(event) {
  searchedInput = event.target.value.toLowerCase();
  console.log({ searchedInput });
  renderProducts();
};
 
function onChangeSorting(event) {
  console.log({ event })
  const sortOption = event.target.value;
  filters = {
    ...filters,
    sortBy: sortOption
  };
  renderProducts();
}
 
function setTotalCount() {
  const resultDivRef = document.getElementById("results-count");
  resultDivRef.innerHTML = `${displayedProducts.length} results`;
}

function sortProducts(products) {
  const sortingCriteria = filters.sortBy;
  if (sortingCriteria === 'asc') {
    return products.sort((a, b) => a.price - b.price);
  } else if (sortingCriteria === 'desc') {
    return products.sort((a, b) => b.price - a.price);
  }
  return products;
}

function getFilteredProductsAfterSearch(products, searchInput) {
  return products.filter(product =>
    product.title.toLowerCase().includes(searchInput) ||
    product.category.toLowerCase().includes(searchInput)
);
}